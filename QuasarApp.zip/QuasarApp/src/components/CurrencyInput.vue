<template>
    <!-- For Vue 2 -->
  <q-input
    ref="inputRef"
    :value="formattedValue"
    outlined
  />
  <!-- For Vue 3
    <q-input
    ref="inputRef"
    :modelValue="formattedValue"
    outlined
  /> -->
</template>

<script>
import useCurrencyInput from 'vue-currency-input'

export default {
  name: 'CurrencyInput',
  props: {
    value: Number, // Vue 2: value
    // modelValue: Number, // Vue 3: modelValue
    options: Object
  },
  setup (props) {
    const { formattedValue, inputRef } = useCurrencyInput(props.options)

    return { inputRef, formattedValue }
  }
}
</script>
