<template>
    <!-- <client-only> -->
        <div>
            <ProductZoomer
                :base-images="images"
                :base-zoomer-options="zoomerOptions"
                :key="$props.atest"
            />
        </div>
    <!-- </client-only> -->
</template>

<script>
export default {
  name: 'Pzoomer',
  props: {
    atest: {
      type: Number,
      required: true
    }
  },
  data () {
    return {
    //   key1: this.$props.atest,
      slide: 1,
      images: {
        thumbs: [
          {
            id: 1,
            url: 'https://source.unsplash.com/random/200x200?sig=1'
          },
          {
            id: 2,
            url: 'https://source.unsplash.com/random/200x200?sig=2'
          },
          {
            id: 3,
            url: 'https://source.unsplash.com/random/200x200?sig=3'
          },
          {
            id: 4,
            url: 'https://source.unsplash.com/random/200x200?sig=4'
          },
          {
            id: 5,
            url: 'https://source.unsplash.com/random/200x200?sig=5'
          }
        ],
        normal_size: [
          {
            id: 1,
            url: 'https://source.unsplash.com/random/400x400?sig=1'
          },
          {
            id: 2,
            url: 'https://source.unsplash.com/random/400x400?sig=2'
          },
          {
            id: 3,
            url: 'https://source.unsplash.com/random/400x400?sig=3'
          },
          {
            id: 4,
            url: 'https://source.unsplash.com/random/400x400?sig=4'
          },
          {
            id: 5,
            url: 'https://source.unsplash.com/random/400x400?sig=5'
          }
        ],
        large_size: [
          {
            id: 1,
            url: 'https://source.unsplash.com/random/400x400?sig=1'
          },
          {
            id: 2,
            url: 'https://source.unsplash.com/random/400x400?sig=2'
          },
          {
            id: 3,
            url: 'https://source.unsplash.com/random/400x400?sig=3'
          },
          {
            id: 4,
            url: 'https://source.unsplash.com/random/400x400?sig=4'
          },
          {
            id: 5,
            url: 'https://source.unsplash.com/random/400x400?sig=5'
          }
        ]
      },
      zoomerOptions: {
        zoomFactor: 3, // scale for zoomer
        pane: 'pane', // three type of pane ['pane', 'container-round', 'container']
        hoverDelay: 300, // how long after the zoomer take effect
        namespace: 'zoomer', // add a namespace for zoomer component, useful when on page have mutiple zoomer
        move_by_click: false, // move image by click thumb image or by mouseover
        scroll_items: 2, // thumbs for scroll
        choosed_thumb_border_color: '#bbdefb', // choosed thumb border color
        scroller_button_style: 'line',
        scroller_position: 'left',
        zoomer_pane_position: 'right'

        // zoomFactor: 3,
        // pane: 'pane',
        // hoverDelay: 300,
        // namespace: 'zoomer-right',
        // move_by_click: false,
        // scroll_items: 2,
        // choosed_thumb_border_color: '#dd2c00',
        // scroller_position: 'left',
        // zoomer_pane_position: 'right'
      }
    }
  },
  created () {
    console.log('child created called')
  },
  mounted () {
    console.log('child called')
    // You may need to do the increment in a setTimeout (as for me doing it after 2 sec because of my skeleton loader)
    // this.key1++
  }
}
</script>
