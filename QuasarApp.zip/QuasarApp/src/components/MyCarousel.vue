<template>
  <q-page class="">
    <div class="q-pa-md">
        <q-carousel
          swipeable
          animated
          v-model="slide"
          thumbnails
          vertical
          navigation-position="left"
          infinite
        >
          <q-carousel-slide :name="1" img-src="https://cdn.quasar.dev/img/mountains.jpg" />
          <q-carousel-slide :name="2" img-src="https://cdn.quasar.dev/img/parallax1.jpg" />
          <q-carousel-slide :name="3" img-src="https://cdn.quasar.dev/img/parallax2.jpg" />
          <q-carousel-slide :name="4" img-src="https://cdn.quasar.dev/img/quasar.jpg" />
          <!-- <q-carousel-slide :name="5" img-src="https://cdn.quasar.dev/img/mountains.jpg" />
          <q-carousel-slide :name="6" img-src="https://cdn.quasar.dev/img/parallax1.jpg" />
          <q-carousel-slide :name="7" img-src="https://cdn.quasar.dev/img/parallax2.jpg" /> -->
        </q-carousel>
    </div>
  </q-page>
</template>

<script>
export default {
  name: 'MyCarousel',
  data () {
    return {
      slide: 1
    }
  }
}
</script>
