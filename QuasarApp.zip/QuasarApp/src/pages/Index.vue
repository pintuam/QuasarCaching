<template>
  <q-page class="">
    <div class="q-pa-md">
      <div class="test"></div>
      <q-btn dense color="secondary" @click="openInApp">Open InApp</q-btn>
    </div>
  </q-page>
</template>

<script>
export default {
  name: 'PageIndex',
  components: {
    // Pzoomer,
    // MyCarousel
    // CurrencyInput
  },
  data () {
    return {
      key1: 1,
      value: 5,
      InAppBrowserRef: null
    }
  },
  mounted () {
    // console.log('parent called')
    // window.addEventListener('load', (event) => {
    //   this.key1++
    // })
  },
  methods: {
    openInApp () {
      document.addEventListener('deviceready', () => {
        this.InAppBrowserRef = cordova.InAppBrowser.open(encodeURI('https://qa.dev.ftxcommerce.com'), '_blank', 'location=yes')
        this.InAppBrowserRef.addEventListener('loaderror', () => {
          this.InAppBrowserRef.inAppBrowserRef.close()
        })
      }, false)
    }
  }
}
</script>

<style lang="scss">
.test {
  width:200px;
  height:200px;
  background-color: $secondary;
}
</style>
