export const firebaseConfig = {
  apiKey: 'AIzaSyCcfJHdoMHDmtUdRn3jjlxx9eKMkCBxBdk',
  authDomain: 'ftx-push.firebaseapp.com',
  databaseURL: 'https://ftx-push.firebaseio.com',
  storageBucket: 'ftx-push.appspot.com',
  messagingSenderId: '602047082515',
  appId: '1:602047082515:web:a5eb8389d2f6b468be8fe6',
  projectId: 'ftx-push'
}
export const firebaseVapidKey = 'BCYFK4N-Q_44UQKv68RdOe8bc-OHVb8Ib7edsCClFWPnE2Z3rpffeqy7eUE8MbkZp0r0bqKIywEUcVCnj-eKEv8'
export const firebaseServerKey = 'AAAAjCzNcBM:APA91bH2X21YuE8Hc7sJNSL5_4Q8XyyJeLgeqhPtT4HqTlSRlmDNooRW280JcG1hrx_9QStJG0INg2on0V__UWroMJRmgngg-DJN2gzIw_8F6dkvbGJ265iIOWa7rFJmJdPhkz3FWCUf'
