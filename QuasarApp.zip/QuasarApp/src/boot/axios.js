/* eslint no-use-before-define: 0 */
import Vue from 'vue'
import axios from 'axios'

Vue.prototype.$axios = axios
