<?php
use Illuminate\Http\Request;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('create', 'StudController@insertform');

Route::get('/', function () {
    return view('welcome');
});

Route::post('insert','StudController@insert');


Route::any('/fetch','StudController@getData');

Route::get('/login',function(){
	return view('login');
});

Route::any('/dologin','StudController@login');


//Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');


Route::group(['prefix' => 'student'], function () {

Route::get('/register', 'StudController@insertform');

Route::post('/register', 'StudController@insert')->name('register');

Route::get('login', 'StudController@studLogin')->name('student-loginview');

Route::post('login', 'StudController@login')->name('student.login');

});

//Route::get('student/dashboard', ['as'=>'student.dashboard','uses' => 'StudentController@dashboard']);

Route::group(['middleware' => ['student'],'prefix' => 'student'], function () {
        

    Route::get('dashboard', ['as'=>'student.dashboard','uses'=>'StudentController@dashboard']);
    //student/dashboard

 //    Route::get('/style',function(){
	// return view('styles');
	// });

	Route::get('edit/{id}', 'StudentController@edit')->name('student-edit');
	//student/edit/id

	Route::post('update', 'StudentController@update')->name('student-update');

	Route::post('delete/{id}', 'StudentController@delete');

	Route::get('logout', 'StudController@logout')->name('logout');

});