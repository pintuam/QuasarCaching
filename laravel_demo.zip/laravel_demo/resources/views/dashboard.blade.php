<!DOCTYPE html>
<html>
<head>
	<title>@yield('title')</title>

	@yield('css')

	@yield('js')
</head>

<body>
<div class="container">

@if (session('update_success'))
    <div class="alert alert-success message">
        {{ session('update_success') }}
    </div>
@endif

@if (session('delete_success'))
    <div class="alert alert-danger message">
        {{ session('delete_success') }}
    </div>
@endif

<!-- for logout -->
<a type="button" class="btn btn-sm btn-primary" href="{{route('logout')}}" >LogOut</a>

<h2>Students Data</h2>
	
	<table class="table table-responsive table-hover">
		<tr>
			<th>Name</th>
			<th>Username</th>
			<th>Email</th>
			<th>Actions</th>
		</tr>
		
		@if($student)
		@foreach($student as $students)
		
		<tr>
			<td>{{$students->name}}</td>
			<td>{{$students->username}}</td>
			<td>{{$students->email}}</td>
			<td><a type="button" class="btn btn-sm btn-primary" onclick="return confirm('Are You sure To Edit?')" href="{{ url('student/edit').'/'.$students->sid }}" >Edit</a>
			<form action="{{ url('student/delete').'/'. $students->sid }}" method="post">
			<input type = "hidden" name="_token" value="<?php echo csrf_token(); ?>">
			<button class="btn btn-sm btn-danger" onclick="return confirm('Are You sure To Delete?')" type="submit">Delete</button>
			</form>
			</td>
		</tr>
		@endforeach
		@endif

	</table>
{{ $student->links() }}
</div>



<script type="text/javascript">
  var message = $( '.message' );
if ( message.length ) {
    setTimeout( function() {
        message.fadeOut( 'slow' );
    }, 2000 );
}
</script>

</body>
</html>