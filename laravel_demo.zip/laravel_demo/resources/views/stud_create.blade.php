<!DOCTYPE html>
<html>
<head>
	<title>Insert Form Demo</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container"> 

<!-- @if (!empty($edit))
	{{$edit[0]->sid}}
@endif -->

@if (session('flash_message'))
    <div class="alert alert-success message">
        {{ session('flash_message') }}
    </div>
@endif



@if (!isset($edit))
<form action = "{{ route('register') }}" method = "post">
@else
<form action = "{{ route('student-update') }}" method = "post">
@endif

<input type = "hidden" name="_token" value="<?php echo csrf_token(); ?>">
<input type="hidden" name="studentid" value="@if (!empty($edit)) {{ $edit[0]->sid}} @endif" />


<table align="center" class="table table-responsive">
<tr>
<td colspan="2" align="center"><b>Insert Table<b></td>
</tr>
<tr>
<td>Name</td>
<td><input type='text' name='name' class="form-control" value="@if (!empty($edit)) {{$edit[0]->name}} @endif {{old('name')}}" />
@if (count($errors) > 0)<p class = "text-danger message">@if($errors->has('name')){{ $errors->first('name') }} @endif</p>@endif
</td>

</tr>

<tr>
<td>UserName</td>
<td><input type='text' name='uname' class="form-control" value="@if (!empty($edit)) {{$edit[0]->username}} @endif {{ old('uname') }}" />
@if (count($errors) > 0)<p class = "text-danger message">@if($errors->has('uname')){{ $errors->first('uname')}} @endif</p>@endif
</td>
</tr>

<tr>
<td>Email</td>
<td><input type='text' name='email' class="form-control" value="@if (!empty($edit)) {{$edit[0]->email}} @endif {{ old('email') }}" />
@if (count($errors) > 0)<p class = "text-danger message">@if($errors->has('email')){{ $errors->first('email')}} @endif</p>@endif
</td>
</tr>

@if (!isset($edit))

<tr>
<td>Password</td>
<td><input type='password' name='pwd' class="form-control" value="{{ old('pwd') }}" />
@if (count($errors) > 0)<p class = "text-danger message">@if($errors->has('pwd')){{ $errors->first('pwd')}} @endif</p>@endif
</td>
</tr>

<tr>
<td>Confirm Password</td>
<td><input type='password' name='cpwd' class="form-control" value="{{ old('cpwd') }}" />
@if (count($errors) > 0)<p class = "text-danger message">@if($errors->has('cpwd')){{ $errors->first('cpwd')}} @endif</p>@endif
</td>
</tr>

@endif

<tr>
@if (!isset($edit))

<td colspan="2" align="center"><input type='submit' name='ins' class="btn btn-primary" value="Register" /></td>

@else

<td colspan="2" align="center"><input type='submit' name='ins' class="btn btn-primary" value="Update" /></td>

@endif
</tr>
</table>

</form>
</div>

<script type="text/javascript">
  var message = $( '.message' );
if ( message.length ) {
    setTimeout( function() {
        message.fadeOut( 'slow' );
    }, 2000 );
}
</script>

</body>
</html>