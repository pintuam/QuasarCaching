<!DOCTYPE html>
<html>
<head>
	<title>Insert Form Demo</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container"> 

{{ Session::get('test') }} <!--  // get session data -->

@if (session('flash_message'))
    <div class="alert alert-success message">
        {{ session('flash_message') }}
    </div>
@endif

<form action = "{{ route('student.login')}}" method = "post">

<input type = "hidden" name="_token" value="<?php echo csrf_token(); ?>">

<table align="center" class="table table-responsive">
<tr>
<td colspan="2" align="center"><b>Insert Table<b></td>
</tr>


<tr>
<td>Email</td>
<td><input type='text' name='email' class="form-control" value="{{ old('email') }}" />
@if (count($errors) > 0)<p class = "text-danger message">@if($errors->has('email')){{ $errors->first('email')}} @endif</p>@endif
</td>
</tr>

<tr>
<td>Password</td>
<td><input type='password' name='pwd' class="form-control" value="{{ old('pwd') }}" />
@if (count($errors) > 0)<p class = "text-danger message">@if($errors->has('pwd')){{ $errors->first('pwd')}} @endif</p>@endif
</td>
</tr>


<tr>
<td colspan="2" align="center"><input type='submit' name='ins' class="btn btn-primary" value="Login" /></td>
</tr>
</table>

</form>
</div>

<script type="text/javascript">
  var message = $( '.message' );
if ( message.length ) {
    setTimeout( function() {
        message.fadeOut( 'slow' );
    }, 2000 );
}
</script>

</body>
</html>