<!DOCTYPE html>
<html>
<head>
	<title><?php echo $__env->yieldContent('title'); ?></title>

	<?php echo $__env->yieldContent('css'); ?>

	<?php echo $__env->yieldContent('js'); ?>
</head>

<body>
<div class="container">

<?php if(session('update_success')): ?>
    <div class="alert alert-success message">
        <?php echo e(session('update_success')); ?>

    </div>
<?php endif; ?>

<?php if(session('delete_success')): ?>
    <div class="alert alert-danger message">
        <?php echo e(session('delete_success')); ?>

    </div>
<?php endif; ?>

<!-- for logout -->
<a type="button" class="btn btn-sm btn-primary" href="<?php echo e(route('logout')); ?>" >LogOut</a>

<h2>Students Data</h2>
	
	<table class="table table-responsive table-hover">
		<tr>
			<th>Name</th>
			<th>Username</th>
			<th>Email</th>
			<th>Actions</th>
		</tr>
		
		<?php if($student): ?>
		<?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $students): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		
		<tr>
			<td><?php echo e($students->name); ?></td>
			<td><?php echo e($students->username); ?></td>
			<td><?php echo e($students->email); ?></td>
			<td><a type="button" class="btn btn-sm btn-primary" onclick="return confirm('Are You sure To Edit?')" href="<?php echo e(url('student/edit').'/'.$students->sid); ?>" >Edit</a>
			<form action="<?php echo e(url('student/delete').'/'. $students->sid); ?>" method="post">
			<input type = "hidden" name="_token" value="<?php echo csrf_token(); ?>">
			<button class="btn btn-sm btn-danger" onclick="return confirm('Are You sure To Delete?')" type="submit">Delete</button>
			</form>
			</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php endif; ?>

	</table>
<?php echo e($student->links()); ?>

</div>



<script type="text/javascript">
  var message = $( '.message' );
if ( message.length ) {
    setTimeout( function() {
        message.fadeOut( 'slow' );
    }, 2000 );
}
</script>

</body>
</html>