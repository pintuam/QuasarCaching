<!DOCTYPE html>
<html>
<head>
	<title>Insert Form Demo</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container"> 

<?php echo e(Session::get('test')); ?> <!--  // get session data -->

<?php if(session('flash_message')): ?>
    <div class="alert alert-success message">
        <?php echo e(session('flash_message')); ?>

    </div>
<?php endif; ?>

<form action = "<?php echo e(route('student.login')); ?>" method = "post">

<input type = "hidden" name="_token" value="<?php echo csrf_token(); ?>">

<table align="center" class="table table-responsive">
<tr>
<td colspan="2" align="center"><b>Insert Table<b></td>
</tr>


<tr>
<td>Email</td>
<td><input type='text' name='email' class="form-control" value="<?php echo e(old('email')); ?>" />
<?php if(count($errors) > 0): ?><p class = "text-danger message"><?php if($errors->has('email')): ?><?php echo e($errors->first('email')); ?> <?php endif; ?></p><?php endif; ?>
</td>
</tr>

<tr>
<td>Password</td>
<td><input type='password' name='pwd' class="form-control" value="<?php echo e(old('pwd')); ?>" />
<?php if(count($errors) > 0): ?><p class = "text-danger message"><?php if($errors->has('pwd')): ?><?php echo e($errors->first('pwd')); ?> <?php endif; ?></p><?php endif; ?>
</td>
</tr>


<tr>
<td colspan="2" align="center"><input type='submit' name='ins' class="btn btn-primary" value="Login" /></td>
</tr>
</table>

</form>
</div>

<script type="text/javascript">
  var message = $( '.message' );
if ( message.length ) {
    setTimeout( function() {
        message.fadeOut( 'slow' );
    }, 2000 );
}
</script>

</body>
</html>