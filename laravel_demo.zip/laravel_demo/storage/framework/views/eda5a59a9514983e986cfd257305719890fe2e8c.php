<div class="container">
	
	<table class="table table-responsive table-hover">
		<tr>
			<th>Name</th>
			<th>Username</th>
			<th>Email</th>
		</tr>
		
		<?php if($student): ?>
		<?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $students): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($students->name); ?></td>
			<td><?php echo e($students->username); ?></td>
			<td><?php echo e($students->email); ?></td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php endif; ?>

	</table>
	
</div>