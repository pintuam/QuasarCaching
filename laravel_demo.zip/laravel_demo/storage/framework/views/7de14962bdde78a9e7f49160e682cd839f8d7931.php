<!DOCTYPE html>
<html>
<head>
	<title>Insert Form Demo</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container"> 

<!-- <?php if(!empty($edit)): ?>
	<?php echo e($edit[0]->sid); ?>

<?php endif; ?> -->

<?php if(session('flash_message')): ?>
    <div class="alert alert-success message">
        <?php echo e(session('flash_message')); ?>

    </div>
<?php endif; ?>



<?php if(!isset($edit)): ?>
<form action = "<?php echo e(route('register')); ?>" method = "post">
<?php else: ?>
<form action = "<?php echo e(route('student-update')); ?>" method = "post">
<?php endif; ?>

<input type = "hidden" name="_token" value="<?php echo csrf_token(); ?>">
<input type="hidden" name="studentid" value="<?php if(!empty($edit)): ?> <?php echo e($edit[0]->sid); ?> <?php endif; ?>" />


<table align="center" class="table table-responsive">
<tr>
<td colspan="2" align="center"><b>Insert Table<b></td>
</tr>
<tr>
<td>Name</td>
<td><input type='text' name='name' class="form-control" value="<?php if(!empty($edit)): ?> <?php echo e($edit[0]->name); ?> <?php endif; ?> <?php echo e(old('name')); ?>" />
<?php if(count($errors) > 0): ?><p class = "text-danger message"><?php if($errors->has('name')): ?><?php echo e($errors->first('name')); ?> <?php endif; ?></p><?php endif; ?>
</td>

</tr>

<tr>
<td>UserName</td>
<td><input type='text' name='uname' class="form-control" value="<?php if(!empty($edit)): ?> <?php echo e($edit[0]->username); ?> <?php endif; ?> <?php echo e(old('uname')); ?>" />
<?php if(count($errors) > 0): ?><p class = "text-danger message"><?php if($errors->has('uname')): ?><?php echo e($errors->first('uname')); ?> <?php endif; ?></p><?php endif; ?>
</td>
</tr>

<tr>
<td>Email</td>
<td><input type='text' name='email' class="form-control" value="<?php if(!empty($edit)): ?> <?php echo e($edit[0]->email); ?> <?php endif; ?> <?php echo e(old('email')); ?>" />
<?php if(count($errors) > 0): ?><p class = "text-danger message"><?php if($errors->has('email')): ?><?php echo e($errors->first('email')); ?> <?php endif; ?></p><?php endif; ?>
</td>
</tr>

<?php if(!isset($edit)): ?>

<tr>
<td>Password</td>
<td><input type='password' name='pwd' class="form-control" value="<?php echo e(old('pwd')); ?>" />
<?php if(count($errors) > 0): ?><p class = "text-danger message"><?php if($errors->has('pwd')): ?><?php echo e($errors->first('pwd')); ?> <?php endif; ?></p><?php endif; ?>
</td>
</tr>

<tr>
<td>Confirm Password</td>
<td><input type='password' name='cpwd' class="form-control" value="<?php echo e(old('cpwd')); ?>" />
<?php if(count($errors) > 0): ?><p class = "text-danger message"><?php if($errors->has('cpwd')): ?><?php echo e($errors->first('cpwd')); ?> <?php endif; ?></p><?php endif; ?>
</td>
</tr>

<?php endif; ?>

<tr>
<?php if(!isset($edit)): ?>

<td colspan="2" align="center"><input type='submit' name='ins' class="btn btn-primary" value="Register" /></td>

<?php else: ?>

<td colspan="2" align="center"><input type='submit' name='ins' class="btn btn-primary" value="Update" /></td>

<?php endif; ?>
</tr>
</table>

</form>
</div>

<script type="text/javascript">
  var message = $( '.message' );
if ( message.length ) {
    setTimeout( function() {
        message.fadeOut( 'slow' );
    }, 2000 );
}
</script>

</body>
</html>