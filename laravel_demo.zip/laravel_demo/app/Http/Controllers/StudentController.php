<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Student;
use App\Students;
use Auth;


class StudentController extends Controller
{
    public function dashboard(Request $request)
    {
        //$request->session()->put('test', 'mohit');      // put data in session
    	$id = Auth::guard('student')->user()->id;
    	
    	$data['student'] = Students::select('sid','name','username','email')->paginate(5);
    	//dd($data['student']->toArray()); exit;
    	return view('styles',$data);		// data pass in dashboard but extends to styles we pass data to styles
    }

    public function edit( $id )
    {

    	//echo $id; exit;
    	$data['edit'] = Students::where('sid',$id)->get();
    	//dd($data['edit']->toArray()); exit;
    	return view('stud_create',$data);
    }

    public function update(Request $request)
    {
    	Students::where('sid',$request->studentid)->update(['name'=>$request->name,'username'=>$request->uname,'email'=>$request->email]);

    	return redirect('student/dashboard')->with('update_success', 'Student List successfully updated');

    }

    public function delete($id)
    {
    	//echo $id; exit;
    	Students::find($id)->delete();
    	return redirect('student/dashboard')->with('delete_success', 'Student List successfully Deleted');
    }
}
