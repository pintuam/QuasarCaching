<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;		// using request object
use DB;		// using database
use App\Http\Requests;		// using request object
use App\Http\Controllers\Controller;
use Session;
use Illuminate\Support\Facades\Redirect;		// redirect to another page
use Validator;		// for validation
use Illuminate\Support\Facades\Input;	// use Input::get
use App\Student;		// Student Model
use Illuminate\Support\Facades\Auth;
use Hash;

class StudController extends Controller
{

    public function insertform(){
		return view('stud_create');
	}

	public function insert(Request $request){


		// print_r($request->all());
  //     $this->validate($request,[
  //        'name'=>'required',
  //        'uname'=>'required|max:8',
  //        'email'=>'required',
  //        'pwd'=>'required'
  //        // 'password'=>'required'
  //     ]);
      // $name = $request->input('name');
      // $username = $request->input('uname');
      // $email = $request->input('email');
      // $password = $request->input('pwd');


      $validation = Validator::make($request->all(),
    array(
        'name' => 'required|alpha',
        'uname' => 'required' ,
        'email' => 'required|email',
        'pwd' => 'required',
        'cpwd' => 'required|same:pwd'
    ),
    array(
        'name.required' => 'please fill Name field',
        'name.alpha' => 'Only Alphabetic Accpted',
        'uname.required' => 'please fill UserName field',
        'email.required' => 'please fill Email field',
        'email.email' => 'Email is Not Valid',
        'pwd.required' => 'please fill Password field',
        'cpwd.required' => 'please fill Password field',
        'cpwd.same' => 'Password Does Not Match'
    )

);

if ( $validation->fails() ) {

	$messages = $validation->messages();
	//return redirect('create')->withErrors($messages);
	return redirect('student/register')->withInput($request->all())->withErrors($messages);
	}
	else
	{

		// insert in database start
	// $data=array('name'=>$name,'username'=>$username,'email'=>$email,'password'=>$password);
	// DB::table('students')->insert($data);
	// echo "Record inserted successfully.<br/>";
		// end


	// start model

		$student = new Student;
		$student->name = $request->name;
		$student->username = $request->uname;
		$student->email = $request->email;
		$student->password = Hash::make($request->pwd);
		$student->save();

	// end
	return Redirect::to('student/login')
	  ->with('flash_message', 'Registration Successful');
	}

	}

	public function getData()
	{
		$flights = Student::all();
		//print_r($flights); die;

		foreach ($flights as $flight) {
    		echo $flight->id;
    		echo $flight->name;
		}

		
	}

    public function studLogin()
    {

        return view('login');
    }


		protected function login(Request $request)
    {
      
        // if ($request->session()->exists('test')) {
        //     print_r($request->session()->all()); exit;
        // }
        // validate the login data 
        //$this->validateLogin($request);
       // dd($request);
        // Attempt to log the user into the application.
        // if ($this->attemptLogin($request)) {
            
        //     echo "if called";die;
        //     return redirect('dashboard');
        // }
        
        // // redirect to admin login
        // return redirect('login')->with([
        //     'status' => 'danger',
        //     'msg' => trans('admin_messages.invalid_credentials')
        // ]);

       $this->validate($request, [
            'email' => 'required|email',
            'pwd' => 'required',
        ],[
        'email.required' => 'Please Enter Email Address',
        'email.eamil' => 'Please Enter Valid Email Address',
        'pwd.required' => 'Please Enter Password'
        ]);

       if (auth()->guard('student')->attempt(['email' => $request->input('email'), 'password' => $request->input('pwd')]))
        {

            return redirect()->route('student.dashboard');
        }else{
            dd('your username and password are wrong.');
        }

    }

    public function logout()
    {
        //dd(Auth::guard('student')->user()); exit;
        Auth::guard('student')->logout();
        return Redirect::route('student-loginview');
    }


	
}
