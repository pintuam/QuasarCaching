<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Students extends Model
{

    protected $table = 'student';
    public $timestamps = false;		// for disable updated_at column while updating data
    protected $primaryKey = 'sid';		//  primary key column is sid not id bydefault it take id column

        protected $fillable = [
        'sid','name', 'username', 'email'
    ];

        protected $hidden = [
        'password', 'remember_token',
    ];

}
